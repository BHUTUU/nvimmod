<p align="center">
<kbd href="#"><img title="NeoVim" src="https://user-images.githubusercontent.com/63346676/119282329-edeeed80-bc56-11eb-95ea-01d8d5ef3782.png"></kbd>
</p>


<kbd> <img src = "https://user-images.githubusercontent.com/63346676/119282668-293dec00-bc58-11eb-9b43-5c1fed01c7f2.png"></kbd>

<details>
  <summary>Installation here</summary>

  ```bash
git clone https://github.com/abhackerofficial/nvim-config.git
cd nvim-config
bash setup install
# Selected alternative for nvim as (vi)
# Complete :)
  ```
</details>
